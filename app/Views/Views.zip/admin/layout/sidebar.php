<div class="app-sidebar sidebar-shadow">
    <div class="app-header__logo">
        <div class="logo-src"></div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="scrollbar-sidebar">
        <div class="app-sidebar__inner">
            <ul class="vertical-nav-menu">
                <li class="app-sidebar__heading">
                    Menu
                </li>
                <li>
                    <a href="<?= base_url("/" . $locale . "/admin") ?>" id="menu-dashboard">
                        <i class="metismenu-icon pe-7s-rocket"></i>
                        Dashboards
                    </a>
                </li>
                <li id="menu-item">
                    <a href="#">
                        <i class="metismenu-icon pe-7s-note2"></i>
                        Item
                        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                    </a>
                    <ul id="menu-item-ul">
                        <li>
                            <a href="<?= base_url("/" . $locale . "/admin/item") ?>" id="menu-item-ul-li">
                                <i class="metismenu-icon"></i>
                                Item
                            </a>
                        </li>
                        <!-- <li>
                            <a href="<?= base_url("/" . $locale . "/admin/item_group") ?>" id="menu-itemgroup-ul-li">
                                <i class="metismenu-icon"></i>
                                Item Group
                            </a>
                        </li> -->
                        <!-- <li>
                            <a href="<?= base_url("/" . $locale . "/admin/item_cost") ?>" id="menu-itemcost-ul-li">
                                <i class="metismenu-icon"></i>
                                Item Cost
                            </a>
                        </li> -->
                        <!-- <li>
                            <a href="<?= base_url("/" . $locale . "/admin/item_stock") ?>" id="menu-itemstock-ul-li">
                                <i class="metismenu-icon"></i>
                                Item Stock
                            </a>
                        </li> -->
                    </ul>
                </li>
                <?php if ($_SESSION['session_admin']['user_level'] != "superadmin") : ?>
                    <li>
                        <a href="<?= base_url("/" . $locale . "/admin/stock") ?>" id="menu-stock">
                            <i class="metismenu-icon pe-7s-copy-file"></i>
                            Histori Stok
                        </a>
                    </li>
                <?php endif; ?>
                <?php if ($_SESSION['session_admin']['user_level'] == "ppic") : ?>
                    <li id="menu-po">
                        <a href="#">
                            <i class="metismenu-icon pe-7s-cash"></i>
                            Pesanan Pembelian
                            <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                        </a>
                        <ul id="menu-po-ul">
                            <li>
                                <a href="<?= base_url("/" . $locale . "/admin/po") ?>" id="menu-po-ul-li">
                                    <i class="metismenu-icon"></i>
                                    Pesanan Pembelian
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if ($_SESSION['session_admin']['user_level'] != "superadmin") : ?>
                    <li id="menu-pr">
                        <a href="#">
                            <i class="metismenu-icon pe-7s-cash"></i>
                            Permintaan Pembelian
                            <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                        </a>
                        <ul id="menu-pr-ul">
                            <li>
                                <a href="<?= base_url("/" . $locale . "/admin/pr") ?>" id="menu-pr-ul-li">
                                    <i class="metismenu-icon"></i>
                                    Permintaan Pembelian
                                </a>
                            </li>
                            <?php if ($_SESSION['session_admin']['user_level'] == "produksi") : ?>
                                <li>
                                    <a href="<?= base_url("/" . $locale . "/admin/pr_add") ?>" id="menu-prd-ul-li">
                                        <i class="metismenu-icon"></i>
                                        Add Permintaan Pembelian
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if ($_SESSION['session_admin']['user_level'] == "superadmin") : ?>
                    <li id="menu-user">
                        <a href="#">
                            <i class="metismenu-icon pe-7s-id"></i>
                            User
                            <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
                        </a>
                        <ul id="menu-user-ul">
                            <li>
                                <a href="<?= base_url("/" . $locale . "/admin/produksi") ?>" id="menu-produksi-ul-li">
                                    <i class="metismenu-icon"></i>
                                    Bagian Produksi
                                </a>
                            </li>

                            <li>
                                <a href="<?= base_url("/" . $locale . "/admin/ppic") ?>" id="menu-ppic-ul-li">
                                    <i class="metismenu-icon"></i>
                                    PPIC
                                </a>
                            </li>

                        </ul>
                    </li>
                <?php endif; ?>

                <?php if ($_SESSION['session_admin']['user_level'] == "ppic") : ?>
                    <li>
                        <a href="<?= base_url("/" . $locale . "/admin/suplier") ?>" id="menu-suplier">
                            <i class="metismenu-icon pe-7s-download"></i>
                            Pemasok
                        </a>
                    </li>
                <?php endif; ?>
                <!-- <li>
                    <a href="<?= base_url("/" . $locale . "/admin/sales") ?>" id="menu-sales">
                        <i class="metismenu-icon pe-7s-users"></i>
                        Sales
                    </a>
                </li> -->
                <!-- <li>
                    <a href="<?= base_url("/" . $locale . "/admin/customer") ?>" id="menu-customer">
                        <i class="metismenu-icon pe-7s-star"></i>
                        Customer
                    </a>
                </li> -->

                <li class="app-sidebar__heading">Pengaturan</li>
                <li>
                    <a href="<?= base_url("/" . $locale . "/admin/profile") ?>" id="menu-profile">
                        <i class="metismenu-icon pe-7s-user"></i>
                        Akun Saya
                    </a>
                </li>
                <li>
                    <a href="<?= base_url("/admin/logout") ?>">
                        <i class="metismenu-icon pe-7s-power"></i>
                        keluar
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>