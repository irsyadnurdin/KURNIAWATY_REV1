<?= $this->extend("admin/layout/admin_layout") ?>

<?= $this->section("content") ?>

<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-config icon-gradient bg-tempting-azure"></i>
                </div>
                <div>
                    Tambahkan Pesanan Pembelian
                    <div class="page-title-subheading">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur modi maiores error cum incidunt dolores itaque! Ex, ipsum officiis ratione nulla quam aut magnam fugiat deserunt, praesentium laboriosam quis perferendis!
                    </div>
                </div>
            </div>
            <!-- ADDITIONAL BUTTON -->
        </div>
    </div>
    <form class="form_po_action" id="form_po_action">
        <div class="row">

            <div class="col-xl-3">
                <div class="main-card mb-3 card">
                    <div class="card-body">
                        <h5 class="card-title">Pesanan Pembelian</h5>
                        <form class="">
                            <div class="position-relative form-group">
                                <label for="po_pr_code">Kode PR</label>
                                <input id="po_pr_code" name="po_pr_code" type="text" value="<?= $pr_code ?>" class="form-control" required="" readonly>
                            </div>
                            <div class="position-relative form-group">
                                <label for="po_sup_code">Pemasok</label>
                                <select id="po_sup_code" name="po_sup_code" class="form-control" required="">
                                    <option value="">Pilih Pemasok...</option>
                                    <?php foreach ($sup_es as $sup) : ?>
                                        <option value=<?= $sup['sup_code'] ?>> <?= $sup['sup_name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="position-relative form-group">
                                <label for="po_total">Total Pesanan Pembelian</label>
                                <input id="po_total" name="po_total" type="number" value="<?= $po_total ?>" class="form-control" min="0" value="0" required="" readonly>
                            </div>
                            <div class="position-relative form-group">
                                <small class="form-text text-muted">
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae magnam velit reiciendis provident, nesciunt dignissimos?
                                </small>
                            </div>
                            <button type="submit" class="mt-1 btn btn-primary">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-xl-9">
                <div class="main-card mb-3 card">
                    <div class="card-body">
                        <h5 class="card-title">Detail Pesanan Pembelian</h5>
                        <table id="datatable_po" class="table table-hover table-striped nowrap" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>Kode Item</th>
                                    <th>Nama Item</th>
                                    <th>Deskripsi Item</th>
                                    <th>Satuan</th>
                                    <th>Kategori</th>
                                    <th>Tipe</th>
                                    <th>Grup</th>
                                    <th>Nomor Spesifikasi</th>
                                    <th>Nomor Katalog</th>
                                    <th>Sub Tipe</th>
                                    <th>Nomor Operasi Unit</th>
                                    <th>Kuantitas</th>
                                    <th>Harga</th>
                                    <th>Suhu Penyimpanan</th>
                                    <th>Bentuk Item</th>
                                    <th>Pembuatan</th>
                                    <th>Kemasan</th>
                                    <th>Ukuran</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($prd_es as $prd) : ?>
                                    <tr>
                                        <td><input type="text" id="pod_item_code" name="pod_item_code[]" value="<?= $prd['prd_item_code'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_item_name" name="pod_item_name[]" value="<?= $prd['prd_item_name'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_item_desc" name="pod_item_desc[]" value="<?= $prd['prd_desc'] ?>" readonly /></td>
                                        <td><input type="text" id="pod_item_unit_measure" name="pod_item_unit_measure[]" value="<?= $prd['prd_measure'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_item_category" name="pod_item_category[]" required /></td>
                                        <td><input type="text" id="pod_item_type" name="pod_item_type[]" required /></td>
                                        <td><input type="text" id="pod_item_group" name="pod_item_group[]" required /></td>
                                        <td><input type="text" id="pod_item_no_spesifikasi" name="pod_item_no_spesifikasi[]" value="<?= $prd['prd_documentation_spesification'] ?>" readonly /></td>
                                        <td><input type="text" id="pod_item_no_catalog" name="pod_item_no_catalog[]" value="<?= $prd['prd_no_catalog'] ?>" readonly /></td>
                                        <td><input type="text" id="pod_item_subtype" name="pod_item_subtype[]" value="Product Master" required /></td>
                                        <td><input type="text" id="pod_item_operating_unit_number" name="pod_item_operating_unit_number[]" /></td>
                                        <td><input type="text" id="pod_prd_qty" name="pod_prd_qty[]" value="<?= $prd['prd_qty'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_prd_price" name="pod_prd_price[]" value="<?= $prd['prd_price'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_prd_storage_temperature" name="pod_prd_storage_temperature[]" value="<?= $prd['prd_storage_temperature'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_prd_item_shape" name="pod_prd_item_shape[]" value="<?= $prd['prd_item_shape'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_prd_manufacture" name="pod_prd_manufacture[]" value="<?= $prd['prd_manufacture'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_prd_packaging" name="pod_prd_packaging[]" value="<?= $prd['prd_packaging'] ?>" readonly required /></td>
                                        <td><input type="text" id="pod_prd_size" name="pod_prd_size[]" value="<?= $prd['prd_size'] ?>" readonly /></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </form>


</div>

<?= $this->endSection() ?>


<?= $this->section("modal") ?>



<?= $this->endSection() ?>


<?= $this->section("javascript") ?>

<script type="text/javascript" language="javascript">
    $(document).ready(function() {
        $("#menu-po").addClass("mm-active");
    })
</script>

<script>
    $(function() {
        var table = $("#datatable_po").DataTable({
            // keys: true,
            // autoFill: true,
            // select: {
            //     style: "single",
            // },
            paging: true,
            lengthChange: true,
            searching: true,
            ordering: true,
            info: true,
            autoWidth: true,
            pageLength: 20,
            colReorder: true,
            // fixedColumns: {
            //     left: 2
            // },
            order: [
                [0, "asc"]
            ],
            // responsive: true,
            columnDefs: [],
            scrollX: true,
            // scrollY: 400,
            // scrollCollapse: true,
            // scroller: true,
            dom: "lfrtip",
            buttons: [{
                text: 'Tambah Item',
                action: function(e, dt, node, config) {
                    $("#modal_po").modal("show");
                }
            }],
        });
    })
</script>

<script>
    $("#form_po_action").submit(function(e) {
        e.preventDefault();

        var url = "<?= base_url("po/insert_po") ?>";

        var formData = new FormData(this);

        count_data = formData.getAll('pod_item_code[]').length;

        if (count_data > 0) {
            var status = true;

            for (let i = 0; i < count_data; i++) {
                if (formData.getAll('pod_price[]')[i] == 0) {
                    status = false;
                }
            }

            if (status) {
                $.ajax({
                    type: "POST",
                    url: url,
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('Authorization', "Bearer " + "<?= $_SESSION['session_admin']['access_token'] ?>");
                    },
                    data: formData,
                    processData: false,
                    contentType: false,
                    cache: false,
                    async: false,
                    success: function(data) {
                        if (data.success) {
                            (async () => {
                                await Swal.fire({
                                    icon: "success",
                                    title: data.t_message,
                                    text: data.message,
                                    showConfirmButton: false,
                                    timer: 2000
                                })

                                window.location.assign("<?= base_url("/" . $locale . "/admin/po") ?>");
                            })()
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: data.t_message,
                                text: data.message,
                                showConfirmButton: false,
                                timer: 2000
                            })
                        }
                    },
                    error: function() {
                        (async () => {
                            await Swal.fire({
                                icon: "error",
                                title: "Oops...",
                                text: "Kesalahan tidak diketahui, halaman akan dimuat ulang!",
                                showConfirmButton: false,
                                timer: 2000
                            })

                            window.location.assign("<?= current_url() ?>");
                        })()
                    }
                })
            } else {
                (async () => {
                    await Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Testing!",
                        showConfirmButton: false,
                        timer: 2000
                    })
                })()
            }
        } else {
            (async () => {
                await Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Detail Pesanan Pembelian Tidak Boleh Kosong!",
                    showConfirmButton: false,
                    timer: 2000
                })
            })()
        }

        return false;
    });
</script>

<?= $this->endSection() ?>