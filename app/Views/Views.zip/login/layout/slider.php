<div class="slider-light">
    <div class="slick-slider">
        <div>
            <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-plum-plate" tabindex="-1">
                <!-- <div class="slide-img-bg" style="background-image: url('assets/images/originals/city.jpg');"></div> -->
                <div class="slider-content">
                    <h3><?= $setting_mstr[0]['stg_value'] ?></h3>
                    <p>
                        <?= $setting_mstr[2]['stg_value'] ?>
                    </p>
                </div>
            </div>
        </div>
        <!-- <div>
        <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-premium-dark" tabindex="-1">
            <div class="slide-img-bg" style="background-image: url('assets/images/originals/citynights.jpg');">
            </div>
            <div class="slider-content">
                <h3>Scalable, Modular, Consistent</h3>
                <p>Easily exclude the components you don't require. Lightweight, consistent
                    Bootstrap based styles across all elements and components
                </p>
            </div>
        </div>
    </div> -->
        <!-- <div>
        <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-sunny-morning" tabindex="-1">
            <div class="slide-img-bg" style="background-image: url('assets/images/originals/citydark.jpg');">
            </div>
            <div class="slider-content">
                <h3>Complex, but lightweight</h3>
                <p>We've included a lot of components that cover almost all use cases for
                    any type of application.</p>
            </div>
        </div>
    </div> -->
    </div>
</div>