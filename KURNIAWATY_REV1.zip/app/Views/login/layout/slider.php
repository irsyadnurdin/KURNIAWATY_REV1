<div class="slider-light">
    <div class="slick-slider">
        <div>
            <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-plum-plate" tabindex="-1">
                <div class="slider-content">
                    <h3><?= $setting_mstr[0]['stg_value'] ?></h3>
                    <p>
                        <?= $setting_mstr[2]['stg_value'] ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>