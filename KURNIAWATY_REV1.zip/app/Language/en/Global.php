<?php

return [
    'h1Title'                      => 'Welcome to CodeIgniter',
    'noteH1Title'                  => 'The small framework with powerful features',
];
