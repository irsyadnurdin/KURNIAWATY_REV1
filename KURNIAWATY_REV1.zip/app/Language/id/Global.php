<?php

return [
    'h1Title'                      => 'Selamat Datang Di CodeIgniter',
    'noteH1Title'                  => 'Kerangka kecil dengan fitur yang kuat',
];
